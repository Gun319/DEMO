﻿using System;
using System.Drawing;
using System.Text;
using ThoughtWorks.QRCode.Codec;

namespace UI
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// 生成二维码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_CreateQRCode_Click(object sender, EventArgs e)
        {
            CreateQRImg(this.txt_QRCode.Text);
        }

        /// <summary>
        /// 生成并保存二维码图片的方法
        /// </summary>
        /// <param name="str">输入的内容</param>
        private void CreateQRImg(string str)
        {
            Bitmap bt;
            string enCodeString = str;
            //生成设置编码实例
            QRCodeEncoder qrCodeEncoder = new QRCodeEncoder();
            //设置二维码的规模 默认 4
            qrCodeEncoder.QRCodeScale = 4;
            //设置二维码的版本 默认 7
            qrCodeEncoder.QRCodeVersion = 7;
            //设置错误检验级别 默认为中等
            qrCodeEncoder.QRCodeErrorCorrect = QRCodeEncoder.ERROR_CORRECTION.M;
            //生成二维码图片
            bt = qrCodeEncoder.Encode(enCodeString, Encoding.UTF8);
            //二维码图片名称
            string filename = DateTime.Now.ToString("yyyyMMMddHHmmss");
            //保存二维码图片在photos路径下
            bt.Save(Server.MapPath("~/photos/") + filename + ".jpg");
            //图片控件要显示的二维码图片路径
            this.img_QRImag.ImageUrl = "~/photos/" + filename + ".jpg";
        }
    }
}